This is a package of modules used in the book The Art and Science of Data Analytics. You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.