def __init__():
    name = "AdvancedAnalytics"
